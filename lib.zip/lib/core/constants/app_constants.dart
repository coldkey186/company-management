// lib/core/constants/app_constants.dart
class AppConstants {
  static const String appName = "Company Management App";
  static const String defaultUserRole = "employee";
  static const int maxFileUploadSize = 25; // MB
}
